const cart = {};
const cartItemsEl = document.getElementById('cart-items');
const cartTotalEl = document.getElementById('cart-total');

function updateCart() {
  cartItemsEl.innerHTML = '';
  let total = 0;
  const keys = Object.keys(cart);
  if (keys.length === 0) {
    cartItemsEl.innerHTML = '<p>Your cart is empty.</p>';
  } else {
    keys.forEach(id => {
      const item = cart[id];
      const line = document.createElement('div');
      line.textContent = `${item.name} x${item.qty} - $${(item.price * item.qty).toFixed(2)}`;
      cartItemsEl.appendChild(line);
      total += item.price * item.qty;
    });
  }
  cartTotalEl.textContent = `Total: $${total.toFixed(2)}`;
}

document.querySelectorAll('.add-to-cart').forEach(btn => {
  btn.addEventListener('click', e => {
    const card = e.target.closest('.product-card');
    const id = card.dataset.id;
    const name = card.dataset.name;
    const price = parseFloat(card.dataset.price);
    if (!cart[id]) cart[id] = { name, price, qty: 0 };
    cart[id].qty++;
    updateCart();
  });
});

updateCart();
